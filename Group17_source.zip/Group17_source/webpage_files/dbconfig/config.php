<?php
/* For my local laptop */
$con = mysqli_connect("localhost", "root", "") OR die("cannot connect");
mysqli_select_db($con,'cs3380db');
?>